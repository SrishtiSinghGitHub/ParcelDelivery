package com.parceldelivery.data;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;

import com.parceldelivery.contants.Constants;
import com.parceldelivery.model.Address;
import com.parceldelivery.model.Container;
import com.parceldelivery.model.Parcel;
import com.parceldelivery.model.SenderReceipient;

public class ParseXMLFiles {
	
	
	public  static Container parseXMLFile()
	{
	try {
		   Container container = new Container(); //Container object
		   List < Parcel > parcels = new ArrayList < Parcel > ();  //Parcel List
		   File xmlFile = new File(Constants.LOCATIONOFCONTAINER);  

		   DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		   DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		   Document doc = dBuilder.parse(xmlFile);
		   doc.getDocumentElement().normalize();

		   //System.out.println("Root Element : " + doc.getDocumentElement().getNodeName());

		   NodeList parcelList = doc.getElementsByTagName(Constants.PARCEL);
		   for (int i = 0; i < parcelList.getLength(); i++) {
		    
			Parcel parcel = new Parcel(); //parcel object
		    Node node = parcelList.item(i);

		    if (node.getNodeType() == Node.ELEMENT_NODE) {
		     Element element = (Element) node;

		     Node sender = element.getElementsByTagName(Constants.SENDER).item(0); //getting sender node
		     Node recp = element.getElementsByTagName(Constants.RECEIPIENTS).item(0); //getting recipients node

		     if (sender.getNodeType() == Node.ELEMENT_NODE && recp.getNodeType() == Node.ELEMENT_NODE) {
		      Element senderElement = (Element) sender;
		      Element recptElement = (Element) recp;

		      Node senderAddress = senderElement.getElementsByTagName(Constants.ADDRESS).item(0);
		      Node RecptAddress = recptElement.getElementsByTagName(Constants.ADDRESS).item(0);

		      if (senderAddress.getNodeType() == Node.ELEMENT_NODE &&
		       RecptAddress.getNodeType() == Node.ELEMENT_NODE) {
		       Element senderAddElement = (Element) senderAddress;
		       Element recptAddElement = (Element) RecptAddress;
		       
		       //setting the sender address
		       Address senderAdd = new Address(senderAddElement.getElementsByTagName(Constants.STREET).item(0).getTextContent(),
		        senderAddElement.getElementsByTagName(Constants.HOUSENUMBER).item(0).getTextContent(),
		        senderAddElement.getElementsByTagName(Constants.POSTALCODE).item(0).getTextContent(),
		        senderAddElement.getElementsByTagName(Constants.CITY).item(0).getTextContent());
		       //setting the recipients address
		       Address recptAdd = new Address(recptAddElement.getElementsByTagName(Constants.STREET).item(0).getTextContent(),
		        recptAddElement.getElementsByTagName(Constants.HOUSENUMBER).item(0).getTextContent(),
		        recptAddElement.getElementsByTagName(Constants.POSTALCODE).item(0).getTextContent(),
		        recptAddElement.getElementsByTagName(Constants.CITY).item(0).getTextContent());
		       //setting sender
		       SenderReceipient sender1 = new SenderReceipient();

		       if(senderElement.getElementsByTagName(Constants.CCNUMBER).getLength()!=0)
		{

		    	 sender1 = new SenderReceipient(senderElement.getElementsByTagName(Constants.NAME).item(0).getTextContent(),
		    		        senderAdd,senderElement.getElementsByTagName(Constants.CCNUMBER).item(0).getTextContent());
		      
		}

		else
		{
			sender1 = new SenderReceipient(senderElement.getElementsByTagName(Constants.NAME).item(0).getTextContent(),
			        senderAdd);

			}//setting recipients
		       SenderReceipient recp1 = new SenderReceipient(recptElement.getElementsByTagName(Constants.NAME).item(0).getTextContent(),
		        recptAdd);
		       //setting parcel object
		       parcel = new Parcel(sender1, recp1,
		        Float.parseFloat(element.getElementsByTagName(Constants.WEIGHT).item(0).getTextContent()),
		        Float.parseFloat(element.getElementsByTagName(Constants.VALUE).item(0).getTextContent()));
		      }

		     }
		    }
		    //adding in the parcellist
		    parcels.add(parcel);
		   }

		   //setting the values in container.
		   container = new Container(doc.getDocumentElement().getElementsByTagName(Constants.ID).item(0).getTextContent(),
		    doc.getDocumentElement().getElementsByTagName(Constants.SHIPPINGDATE).item(0).getTextContent(), parcels);
		   return container;

		  } catch (Exception e) {
		   e.printStackTrace();
		   return null;
		  }
	}

}
