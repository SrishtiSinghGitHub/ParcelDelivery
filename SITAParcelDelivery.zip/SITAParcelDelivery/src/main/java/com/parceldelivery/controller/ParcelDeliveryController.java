package com.parceldelivery.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.parceldelivery.model.Container;
import com.parceldelivery.model.Department;
import com.parceldelivery.model.Parcel;
import com.parceldelivery.service.ParcelDeliveryServiceImp;

@RestController
public class ParcelDeliveryController {
	
	@Autowired
	ParcelDeliveryServiceImp parcelDelivery;
	
	@GetMapping("/container/")
    public Container getContainerDetails()
    {
    	return parcelDelivery.getContainerDetails();
    }
	
	@GetMapping("/container/insurancesignoff")
    public Container signOffByInsurance()
    {
    	return parcelDelivery.signOffByInsurance();
    }
	
	
	@GetMapping("/departments/")
	public List<Department> getAllDepartment()
	{
		return parcelDelivery.getAllDepartment();
	}
	
	@RequestMapping(value = "/department/add", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE},
	consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Department> addDepartment(@RequestBody Department newDepartment, UriComponentsBuilder builder)
	{
		Department department= parcelDelivery.addDepartment(newDepartment);
		if(department== null)
		{
			return ResponseEntity.noContent().build();
		}
		
		HttpHeaders headers= new HttpHeaders();
		headers.setLocation(builder.path("/department/{deptName}").buildAndExpand(department.getDepartmentName()).toUri());
		return new ResponseEntity<Department>(department, HttpStatus.CREATED);
				//new ResponseEntity<Department>(headers, HttpStatus.CREATED);
	}
	
	@DeleteMapping("/department/{departmentName}")
	public ResponseEntity<Void> deleteDepartment(@PathVariable String departmentName)
	{
		System.out.println("InController");
	  	Department d= parcelDelivery.getAllDepartmentByName(departmentName);
	  	if(d== null)
	  	{
	  		return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
	  	}
	  	System.out.println("InController  value===> "+d.getLowerLimit());
	  	parcelDelivery.deleteDepartment(departmentName);
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);

	}
	

}
