package com.parceldelivery.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.parceldelivery.contants.Constants;
import com.parceldelivery.data.ParseXMLFiles;
import com.parceldelivery.model.Container;
import com.parceldelivery.model.Department;
import com.parceldelivery.model.Parcel;

@Service
public class ParcelDeliveryServiceImp implements ParcelDeliverySevice{

	public static Container container;
	public static List<Department> departmentList= new ArrayList<Department>();
	static
	{
	container = ParseXMLFiles.parseXMLFile();
		
    Department d1= new Department("MAIL", 0.0F, 1.0F);
    Department d2= new Department("REGULAR", 1.0F, 10.0F);
    Department d3= new Department("HEAVY", 10.0F, 100.0F);
    Department[] array= {d1, d2, d3};
    for (int i=0; i<array.length;i++)
    {
    	departmentList.add(array[i]);
    }
	}
    
    
	@Override
	public Container getContainerDetails() {
		setTheDepartment(container, departmentList);
		return container;
	}

	@Override
	public Container signOffByInsurance() {
		signOffByInsurance(container);
		handleInsuranceDepartment(container, departmentList);
		return container;
	}

	@Override
	public List<Department> getAllDepartment() {
		// TODO Auto-generated method stub
		return departmentList;
	}
    
	@Override
	public Department getAllDepartmentByName(String deptName) {
		// TODO Auto-generated method stub
		return getDepartmentByName(deptName, departmentList);
	}
	
	@Override
	public Department addDepartment(Department department) {
    	departmentList.add(department);
    	setTheDepartment(container, departmentList);
		System.out.println("departmentList  size===> "+departmentList.size());		
         return department;
	}

	@Override
	public void deleteDepartment(String departmentName) {
		System.out.println("deleteDepartment  value===> "+departmentName);		
		Iterator<Department> iter = departmentList.iterator();
		while(iter.hasNext())
		{
			if(iter.next().getDepartmentName().equals(departmentName))
			{
				System.out.println("Inside");
				iter.remove();
			}
		}
		System.out.println("deleteDepartment  size===> "+departmentList.size());		

	}
    
	
	public  static void setTheDepartment(Container container, List<Department> departmentList)
	{
		List<Parcel> parcelList= container.getParcel();
		for (Parcel p : parcelList)
		{
		    if(p.getValue()<1000)
		    {
		       for(Department d: departmentList)
		       {
		    	  if(p.getWeight()>d.getLowerLimit() &&p.getWeight()<=d.getUpperLimit()) 
		    	  {
		    		  p.setDepartment(d.getDepartmentName());
					  p.setInsuranceSignOff(Constants.INSURANCENOTAPPLICABLE);

		    	  }
		       }
		    }
		    else  // Insurance department
		    {
		    	p.setDepartment(Constants.INSURANCE_DEPARTMENT);
				p.setInsuranceSignOff(Constants.INSURANCENOTSIGNEDOFF);

		    }
		}
     }
	
	public static void signOffByInsurance(Container container)
	{
		List<Parcel> parcelList= container.getParcel();
		for (Parcel p : parcelList)
		{
           if(p.getDepartment().equals(Constants.INSURANCE_DEPARTMENT))
           {
        	   System.out.println("Everything is fine: Signing Off from Insurance Department");
               p.setInsuranceSignOff(Constants.INSURANCESIGNEDOFF);
           }
		}
	}
	
	public static void handleInsuranceDepartment(Container container, List<Department> departmentList)
	{
		List<Parcel> parcelList= container.getParcel();
		for (Parcel p : parcelList)
		{
			if(p.getDepartment().equals(Constants.INSURANCE_DEPARTMENT) && p.getInsuranceSignOff().equals(Constants.INSURANCESIGNEDOFF))
			{
				for(Department d: departmentList)
			       {
			    	  if(p.getWeight()>d.getLowerLimit() &&p.getWeight()<=d.getUpperLimit()) 
			    	  {
			    		  p.setDepartment(d.getDepartmentName());
						  p.setInsuranceSignOff(Constants.INSURANCESIGNEDOFF);

			    	  }
			       }	  
			}
		}
		
		}
	
	public static Department getDepartmentByName(String deptName, List<Department> departmentList)
	{
		System.out.println("getDepartmentByName  ==>  "+deptName +"=== "+ departmentList.size());
		for(Department d: departmentList)
		{
			System.out.println("Inside");

			if(d.getDepartmentName().equals(deptName))
			return d;
		}
		
		return null;
	}


	
	
}

