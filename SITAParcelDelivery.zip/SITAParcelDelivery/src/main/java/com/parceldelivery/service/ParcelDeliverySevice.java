package com.parceldelivery.service;

import java.util.List;

import com.parceldelivery.model.Container;
import com.parceldelivery.model.Department;
import com.parceldelivery.model.Parcel;

public interface ParcelDeliverySevice {
	
	public Container getContainerDetails();
		
	public Container signOffByInsurance();
	
	public List<Department> getAllDepartment();
	
	public Department getAllDepartmentByName( String deptName);
	
	public Department addDepartment(Department department);
	
	public void deleteDepartment(String departmentName);
	

}
