package com.parceldelivery.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.parceldelivery.model.Parcel;

@Repository
public class Container {
	
	private String id;
	private String date;
	List<Parcel> parcel= new ArrayList<Parcel>();
	
	public Container() {
		super();
	}

	public Container(String id, String date, List<Parcel> parcel) {
		super();
		this.id = id;
		this.date = date;
		this.parcel = parcel;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public List<Parcel> getParcel() {
		return parcel;
	}

	public void setParcel(List<Parcel> parcel) {
		this.parcel = parcel;
	}
	

}
