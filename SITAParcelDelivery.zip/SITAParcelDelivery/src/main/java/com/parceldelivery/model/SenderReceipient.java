package com.parceldelivery.model;

import org.springframework.stereotype.Repository;

import com.parceldelivery.model.Address;


public class SenderReceipient {
	
	private String name;
	private Address address = new Address();
	private String ccNumber;
	
	public SenderReceipient() {
		super();
	}

	public SenderReceipient(String name, Address address) {
		super();
		this.name = name;
		this.address = address;
	}

	public SenderReceipient(String name, Address address, String ccNumber) {
		super();
		this.name = name;
		this.address = address;
		this.ccNumber = ccNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCcNumber() {
		return ccNumber;
	}

	public void setCcNumber(String ccNumber) {
		this.ccNumber = ccNumber;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
	

}
