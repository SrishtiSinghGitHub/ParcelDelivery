package com.parceldelivery.model;

import org.springframework.stereotype.Repository;

import com.parceldelivery.model.SenderReceipient;


public class Parcel {
	
	private SenderReceipient sender =new SenderReceipient();
	private SenderReceipient receipeint = new SenderReceipient();
	private float weight;
	private float value;
	private String department;
	private String insuranceSignOff;
	
	public Parcel() {
		super();
	}

	public Parcel(SenderReceipient sender, SenderReceipient receipeint, float weight, float value) {
		super();
		this.sender = sender;
		this.receipeint = receipeint;
		this.weight = weight;
		this.value = value;
	}

	public float getWeight() {
		return weight;
	}

	public void setWeight(float weight) {
		this.weight = weight;
	}

	public float getValue() {
		return value;
	}

	public void setValue(float value) {
		this.value = value;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public SenderReceipient getSender() {
		return sender;
	}

	public void setSender(SenderReceipient sender) {
		this.sender = sender;
	}

	public SenderReceipient getReceipeint() {
		return receipeint;
	}

	public void setReceipeint(SenderReceipient receipeint) {
		this.receipeint = receipeint;
	}

	public String getInsuranceSignOff() {
		return insuranceSignOff;
	}

	public void setInsuranceSignOff(String insuranceSignOff) {
		this.insuranceSignOff = insuranceSignOff;
	}
	

}
