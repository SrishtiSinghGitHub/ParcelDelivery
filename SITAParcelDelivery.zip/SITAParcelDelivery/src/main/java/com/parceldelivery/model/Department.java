package com.parceldelivery.model;

import java.util.List;

import org.springframework.stereotype.Repository;


public class Department {
	private String departmentName;
	private float lowerLimit; 
	private float upperLimit; 

	
	
	public Department() {
		super();
	}



	public Department(String departmentName, float lowerLimit, float upperLimit) {
		super();
		this.departmentName = departmentName;
		this.lowerLimit = lowerLimit;
		this.upperLimit = upperLimit;
	}



	public String getDepartmentName() {
		return departmentName;
	}



	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}



	public float getLowerLimit() {
		return lowerLimit;
	}



	public void setLowerLimit(float lowerLimit) {
		this.lowerLimit = lowerLimit;
	}



	public float getUpperLimit() {
		return upperLimit;
	}



	public void setUpperLimit(float upperLimit) {
		this.upperLimit = upperLimit;
	}
	
}
