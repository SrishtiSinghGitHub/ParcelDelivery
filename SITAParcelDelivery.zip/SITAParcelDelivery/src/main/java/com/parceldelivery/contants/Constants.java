package com.parceldelivery.contants;

public class Constants {
	
	public static String LOCATIONOFCONTAINER= "C:\\ParcelDelivery\\Data\\Container_68465468.xml";
   
	public static String PROPERTYFILE_XMLVARIABLE="file.XMLContainerFile";
	public static String ADDRESS= "Address";
    public static String STREET="Street";
    public static String HOUSENUMBER="HouseNumber";
    public static String POSTALCODE="PostalCode";
    public static String CITY ="City";
    
    public static String CCNUMBER="CcNumber";
    
    public static String NAME= "Name";
    public static String SENDER="Sender";
    public static String RECEIPIENTS="Receipient";
    
    public static String WEIGHT="Weight";
    public static String VALUE="Value";
    
    public static String PARCEL="Parcel";
    
    public static String SHIPPINGDATE="ShippingDate";
    
    public static String ID= "Id";
    
    public static String CONTAINER="Container";
    
    public static String MAIL_DEPARTMENT="Mail";
    public static String REGULAR_DEPARTMENT="Regular";
    public static String HEAVY_DEPARTMENT="Heavy";
    
    public static String INSURANCE_DEPARTMENT="Insurance";
    public static String INSURANCESIGNEDOFF="Y";
    public static String INSURANCENOTSIGNEDOFF="N";
    public static String INSURANCENOTAPPLICABLE="NA";
}
